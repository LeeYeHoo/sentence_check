/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sentence_check;

import java.util.Scanner;
import static java.lang.System.out;
/**
 *
 * @author student
 */
public class Sentence_check {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        String sentence, word;
        
        out.print("Enter a sentence : ");
        sentence = s.nextLine();
        
        out.print("\nEnter a word to find : ");
        word = s.next();
        
        if(sentence.length() >= word.length()){
            if( isFound(stringToArr(sentence), stringToArr(word)) == true){
                out.println("\n"+word+" is Founded From sentence '"+sentence+"'");
            }else{
                out.println("\nWord not Founded");
            }
        }
    }
    
    public static char[] stringToArr(String s){
        char[] ret = new char[s.length()];
        
        for(int i=0; i < ret.length; i++){
            ret[i] = s.charAt(i);
        }
        
        return ret;
    }
    
    public static boolean isFound(char[] sentence, char[] word){
        int index_sen = 0, y = 0;
        boolean isFound = false;
        
        for(int x=0; x < sentence.length; x++){
            index_sen = x;
            for(y=0; y < word.length && sentence[index_sen ++] == word[y]; y++){}
            
            if(y == word.length){
                isFound = true;
                break;
            }
        }
        
        return isFound;
    }
}
